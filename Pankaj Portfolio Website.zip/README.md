
  # Create Unique Portfolio Website

  This is a code bundle for Create Unique Portfolio Website. The original project is available at https://www.figma.com/design/uRWfJqYUHQ3X6n5gGmrrNw/Create-Unique-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  